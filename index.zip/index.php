<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
	<title>The Wise Investing | Home</title>
	<meta name="description"  content="" />
	<meta name="author" content="">
	<meta name="keywords"  content="" />
	<meta property="og:title" content="" />
	<meta property="og:type" content="" />
	<meta property="og:url" content="" />
	<meta property="og:image" content="" />
	<meta property="og:image:width" content="470" />
	<meta property="og:image:height" content="246" />
	<meta property="og:site_name" content="" />
	<meta property="og:description" content="" />
	<meta name="twitter:card" content="" />
	<meta name="twitter:site" content="" />
	<meta name="twitter:domain" content="" />
	<meta name="twitter:title" content="" />
	<meta name="twitter:description" content="" />
	<meta name="twitter:image" content="" />

	<!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="theme-color" content="#212121"/>
    <meta name="msapplication-navbutton-color" content="#212121"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="#212121"/>
    <!-- Theme style CSS --> 
	<?php 
	include('head_code.php');
	?>

        <!-- ==============================================
        Favicons
        =============================================== -->
        <link rel="shortcut icon" href="assets/images/favicon.png">
        <link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="72x72" href="assets/images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="assets/images/apple-touch-icon-114x114.png">

        <!-- ==============================================
        Vendor Stylesheet
        =============================================== -->
        <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/vendor/slider.min.css">
        <link rel="stylesheet" href="assets/css/main.css">
        <link rel="stylesheet" href="assets/css/vendor/icons.min.css">
        <link rel="stylesheet" href="assets/css/vendor/animation.min.css">
        <link rel="stylesheet" href="assets/css/vendor/gallery.min.css">
        
        <!-- ==============================================
        Custom Stylesheet
        =============================================== -->
        <link rel="stylesheet" href="assets/css/default.css">
        <link rel="stylesheet" href="assets/css/theme-orange.css">
        <link rel="stylesheet" href="assets/css/custom.css">

        <!-- ==============================================
        Theme Settings
        =============================================== -->
        <style>
            :root {               
                --header-bg-color: #040402;
                --nav-item-color: #f5f5f5;
                --top-nav-item-color: #f5f5f5;
                --hero-bg-color: #040402;

                --section-1-bg-color: #111111;
                --section-2-bg-color: #191919;
                --section-3-bg-color: #040402;
                --section-4-bg-color: #111111;
                --section-5-bg-color: #191919;
                --section-6-bg-color: #040402;
                --section-7-bg-color: #111111;
            
                --footer-bg-color: #191919;
            }
			
			.card span {
    margin-top: 0;
    white-space: pre-wrap;
	color:#fc5130;
}

.card:not(.no-hover):hover h3, .card:not(.no-hover):hover h4, .card:not(.no-hover):hover span {
    color: #f5f5f5;
}
        </style>
        
    </head>

    <body class="theme-mode-dark">

        <!-- Header -->
        <?php 
		include('header.php');
		?>

        <!-- Hero -->
        <section id="slider" class="hero p-0 odd">
            <div class="swiper-container full-slider featured animation slider-h-100">
                <div class="swiper-wrapper">

                    <!-- Item 1 -->
                    <div class="swiper-slide slide-center">
                        <img data-aos="zoom-out-up" data-aos-delay="800" src="assets/images/banner1.jpg" class="hero-image" alt="Hero Image">
                        <div class="slide-content row" data-mask-768="50">
                            <div class="col-12 d-flex inner">
                                <div class="left align-self-center text-center text-md-left">
                                    <h1 data-aos="zoom-out-up" data-aos-delay="400" class="title effect-static-text" style="font-size:40px;">Your Money, Our Mind!</h1>
                                    <p data-aos="zoom-out-up" data-aos-delay="800" class="description">Money isn’t multiplied in the locker. Invest with us and see your money grow!</p>
                                    <a href="#contact" data-aos="zoom-out-up" data-aos-delay="1200" class="smooth-anchor ml-auto mr-auto ml-md-0 mt-4 btn dark-button">READ MORE</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Item 2 -->
                    <div class="swiper-slide slide-center">
                        <img data-aos="zoom-out-up" data-aos-delay="800" src="assets/images/hero-5.jpg" class="hero-image" alt="Hero Image">
                        <div class="slide-content row" data-mask-768="50">
                            <div class="col-12 d-flex inner">
                                <div class="left align-self-center text-center text-md-left">
                                    <h2 data-aos="zoom-out-up" data-aos-delay="400" class="title effect-static-text" style="font-size:40px;">Investment brews in <br/>the cup of patience</h2>
                                    <p data-aos="zoom-out-up" data-aos-delay="800" class="description">Patience is the key to invest in the stock market. Let experts handle your portfolio to fetch you fruitful results.</p>
                                    <a href="#contact" data-aos="zoom-out-up" data-aos-delay="1200" class="smooth-anchor ml-auto mr-auto ml-md-0 mt-4 btn dark-button">READ MORE</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Item 3 -->
                    <div class="swiper-slide slide-center">
                        <img data-aos="zoom-out-up" data-aos-delay="800" src="assets/images/banner3.jpg" class="hero-image" alt="Hero Image">
                        <div class="slide-content row" data-mask-768="50">
                            <div class="col-12 d-flex inner">
                                <div class="left align-self-center text-center text-md-left">
                                    <h2 data-aos="zoom-out-up" data-aos-delay="400" class="title effect-static-text" style="font-size:40px;">It’s never too late <br/>to earn!</h2>
                                    <p data-aos="zoom-out-up" data-aos-delay="800" class="description">Earning and earning is not the concept of happy living. Earning with investing is the perfect combination for a wealthy life.</p>
                                    <a href="#contact" data-aos="zoom-out-up" data-aos-delay="1200" class="smooth-anchor ml-auto mr-auto ml-md-0 mt-4 btn dark-button">READ MORE</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="swiper-pagination"></div>
            </div>
        </section>

        <!-- About [image] -->
        <section id="about" class="section-1 odd highlights image-right">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 align-self-center text-center text-md-left">
                        <div class="row intro">
                            <div class="col-12 p-0">
                                <h2 class="featured alt">About Us</h2>
                                <p style="text-align:justify;">Wise Investing is a well diversified financial service company that alerts you to pick on the best assets for portfolio creation, based on exhaustive research and extensive market driven data. </p>
<p style="text-align:justify;">The Wise Investing is a result of two young and ingenious minds who hold 14 years of professional experience in picking precise and propitious assets that ensure steady growth of your portfolio.</p>
<p style="text-align:justify;">We believe in growing together, choose  Wise Investing for a secured future!
</p>
                            </div>
                        </div>
                        <div class="row items">
                            <div class="col-12 p-0">
                                <div class="row item">
                                    <div class="col-12 col-md-2 align-self-center">
                                       <!-- <i class="icon icon-badge"></i>-->
                                    </div>
                                    <div class="col-12 col-md-9 align-self-center">
                                        <!--<h4>Quality</h4>
                                        <p>Everything we do has the commitment of a well trained and motivated team.</p>-->
                                    </div>  
                                </div>
                                <div class="row item">
                                    <div class="col-12 col-md-2 align-self-center">
                                       <!-- <i class="icon icon-briefcase"></i>-->
                                    </div>
                                    <div class="col-12 col-md-9 align-self-center">
                                       <!-- <h4>Experience</h4>
                                        <p>Focused on results we seek to raise the level of our customers.</p>-->
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        
                            <img src="assets/images/home-about.jpg" class="fit-image" alt="About Us">
                       
                    </div>
                </div>
            </div>
        </section>


		<section id="features" class="section-2 odd offers" style="padding: 50px 0;">
            <div class="container">
                <div class="row justify-content-center text-center items">
                    <div class="col-12 col-md-6 col-lg-6 item">
                        <div class="card no-hover">
                           <a href="why-invest.php"> <img src="assets/images/investing.png" style="width: auto;
    height: 44px;
    line-height: 44px;
    text-align: center;
    font-size: 44px;
    display: block;
    margin: auto;" /></a>
                            <h4><a href="why-invest.php">Investing</a></h4>
                            <p>Investing focuses on spending your money on buying assets with the expectation that your investment will give you higher returns.</p>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 item">
                        <div class="card no-hover">
                          <a href="why-invest.php">  <img src="assets/images/savings.png" style="width: auto;
    height: 44px;
    line-height: 44px;
    text-align: center;
    font-size: 44px;
    display: block;
    margin: auto;" /></a>
                            <h4><a href="why-invest.php">Savings</a></h4>
                            <p>Saving is just setting aside money you don’t spend now for emergencies, retirement or even for a future purchase.</p>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
		
        <!-- About [video] -->
        <section class="section-2 odd highlights image-left" style="padding-top: 50px;">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                        
                            <img src="assets/images/why-us.jpg" class="fit-image" alt="Institutional">
                        
                    </div>
                    <div class="col-12 col-md-6 pl-md-5 align-self-center text-center text-md-left">
                        <div class="row intro">
                            <div class="col-12 p-0">
                                <h2 class="featured alt">Why Us</h2>
                                <p style="text-align:justify;">We don’t just offer you safe investments, we do it the optimal way.</p>
								<p style="text-align:justify;">Looking for the right investment opportunity by yourself can be a tiresome process, leave it to us for wise return and investments. We as an expert ,research the assets and pick out the best investment opportunity with our machine learning tools.  The Wise Investing holds an edge towards competitors in terms of return, on an average our hand picked stocks offer 10-15% ROI. What’s in it for us? We just want to level the playing field by making investing easy for both rookies and professionals.
                                </p>
                            </div>
                        </div>
                        <div class="row items">
                            <div class="col-12 p-0">
                                <div class="row item">
                                    <div class="col-12 col-md-2 align-self-center">
                                        <!--<i class="icon icon-trophy"></i>-->
                                    </div>
                                    <div class="col-12 col-md-9 align-self-center">
                                       <!-- <h4>Tradition</h4>
                                        <p>We are excellence in developing web solutions for companies.</p>-->
                                    </div>  
                                </div>
                                <div class="row item">
                                    <!--<div class="col-12 col-md-2 align-self-center">
                                        <i class="icon icon-diamond"></i>
                                    </div>-->
                                    <div class="col-12 col-md-9 align-self-center">
                                        <!--<h4>Innovation</h4>
                                        <p>We seek to build something that changes people's lives.</p>-->
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
		
		<section id="services" class="section-4 odd offers featured">
            <div class="container">
                <div class="row intro">
                    <div class="col-12 col-md-9 align-self-center text-center text-md-left">
                        <h2 class="featured">Our Services</h2>
                        <p>Focused on results we seek to raise the level of our customers.</p>
                    </div>
                    <div class="col-12 col-md-3 align-self-end">
                        <a href="#" class="btn mx-auto mr-md-0 ml-md-auto primary-button"><i class="icon-grid"></i>VIEW ALL</a>
                    </div>
                </div>
                <div class="row justify-content-center items">
                    <div class="col-12 col-md-6 col-lg-6 item">
                        <div class="card featured" style="padding-bottom:59px;">
                            <i class="icon icon-globe" style="width:auto;
    height: 44px;
    line-height: 44px;
    text-align: left;
    font-size: 44px;
    display: block;
	margin: unset;"></i>
                            <h4>Long Holding Periods</h4>
							 <span>“Time in the market beats timing in the market” - Ken Fisher</span>
                            <p style="padding-top:10px;">Patience is necessary while waiting for a seed to grow into a bearing fruit. Likewise you must be forbearing while investing. Think ahead and choose the next best investment opportunity that fetches rewards in the long run, we help in providing long term investment and swing trade ideas.</p>
                           
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 item">
                        <div class="card">
                            <i class="icon icon-basket" style="width:auto;
    height: 44px;
    line-height: 44px;
    text-align: left;
    font-size: 44px;
    display: block;
	margin: unset;"></i>
                            <h4>Nominal Rates</h4>
							 <span>“The stock market is filled with individuals who know the price of everything, but the value of nothing” – Phillip Fisher</span>
                            <p style="padding-top:10px;">Would you prefer to buy an overvalued asset? Then why would you overpay for an investment insight service? Unlike our competitors, we provide the best recommendations for a fraction of the price. Invest with The Wise Investing with nominal rates to enjoy the better future! </p>
                           
                        </div>
                    </div>
                    
                   
                    <div class="col-12 col-md-6 col-lg-6 item">
                        <div class="card" style="padding-bottom:59px;">
                            <i class="icon icon-chart" style="width:auto;
    height: 44px;
    line-height: 44px;
    text-align: left;
    font-size: 44px;
    display: block;
	margin: unset;"></i>
                            <h4>Valuable Insights</h4>
							<span>"Without data you’re just another person with an opinion” – W. Edwards Deming </span>
                            <p style="padding-top:10px;">We simply want the best for you. Get Updated every week with market reports and individual asset insight reports, which in turn serves as a base for making investment related decisions. Informed Investor is better than an impatient trader!</p>
                           
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 item">
                        <div class="card featured">
                            <i class="icon icon-bulb" style="width:auto;
    height: 44px;
    line-height: 44px;
    text-align: left;
    font-size: 44px;
    display: block;
	margin: unset;"></i>
                            <h4>Market Analysis</h4>
							<span>“In investing, what is comfortable is rarely profitable.” - Robert Arnott</span>
                            <p style="padding-top:10px;">We have developed the best in class stock screener that helps us read and predict the market, to recommend you the  best stocks based on your portfolio. Our stock screener takes in multiple arguments and scans the entire stock market to analyse and forecast the movements, making us accurate and precise</p>
                           
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
<section id="team" class="section-4 carousel featured card-white">
            <div class="overflow-holder">
                <div class="container">
                    <div class="row text-center intro">
                        <div class="col-12">
                            <h2 class="super effect-static-text">Our Recent Picks</h2>
                            <p class="text-max-800">Our team will help you define a stand-out creative direction and will translate it into visual assets that will resonate with your audience.</p>
                        </div>
                    </div>
                    <div class="swiper-container mid-slider-simple items">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide slide-center text-center item">
                                <div class="row card" style="padding:0px;">
                                    <div class="col-12" style="padding:0px;">
                                        <img src="assets/images/1.png" alt="Adams Baker" class="person">
                                        <h4 style="margin-top:10px;margin-bottom:10px;padding-top:10px;">PRPO</h4>
                                        <p style="padding-bottom:10px;">TOTAL RETURN : 534.92%</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                  <div class="row card" style="padding:0px;">
                                    <div class="col-12" style="padding:0px;">
                                        <img src="assets/images/1.png" alt="Adams Baker" class="person">
                                        <h4 style="margin-top:10px;margin-bottom:10px;padding-top:10px;">PRPO</h4>
                                        <p style="padding-bottom:10px;">TOTAL RETURN : 534.92%</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                  <div class="row card" style="padding:0px;">
                                    <div class="col-12" style="padding:0px;">
                                        <img src="assets/images/1.png" alt="Adams Baker" class="person">
                                        <h4 style="margin-top:10px;margin-bottom:10px;padding-top:10px;">PRPO</h4>
                                        <p style="padding-bottom:10px;">TOTAL RETURN : 534.92%</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                   <div class="row card" style="padding:0px;">
                                    <div class="col-12" style="padding:0px;">
                                        <img src="assets/images/1.png" alt="Adams Baker" class="person">
                                        <h4 style="margin-top:10px;margin-bottom:10px;padding-top:10px;">PRPO</h4>
                                        <p style="padding-bottom:10px;">TOTAL RETURN : 534.92%</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                   <div class="row card" style="padding:0px;">
                                    <div class="col-12" style="padding:0px;">
                                        <img src="assets/images/1.png" alt="Adams Baker" class="person">
                                        <h4 style="margin-top:10px;margin-bottom:10px;padding-top:10px;">PRPO</h4>
                                        <p style="padding-bottom:10px;">TOTAL RETURN : 534.92%</p>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </section>
		

        <!-- News -->
        <section id="news" class="section-5 odd carousel showcase news">
            <div class="overflow-holder">
                <div class="container">
                    <div class="row intro">
                        <div class="col-12 col-md-9 align-self-center text-center text-md-left">
                            <h2 class="featured">Latest Blogs</h2>
                            <p>Every week we publish exclusive content on various topics.</p>
                        </div>
                        <div class="col-12 col-md-3 align-self-end">
                            <a href="#" class="btn mx-auto mr-md-0 ml-md-auto primary-button"><i class="icon-grid"></i>VIEW ALL</a>
                        </div>
                    </div>
                    <div class="swiper-container mid-slider items">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide slide-center item">
                                <div class="row card p-0 text-center">
                                    <div class="image-over">
                                        <img src="assets/images/news-1-h.jpg" alt="Lorem ipsum">
                                    </div>
                                    <div class="card-caption col-12 p-0">
                                        <div class="card-body">
                                            <a href="#">
                                                <h4 class="m-0">Tips for having a good relationship at work.</h4>
                                            </a>
                                        </div>
                                        <div class="card-footer d-lg-flex align-items-center justify-content-center">
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-user"></i>John Doe</a>
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-clock"></i>3 Days Ago</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center item">
                                <div class="row card p-0 text-center">
                                    <div class="image-over">
                                        <img src="assets/images/news-2-h.jpg" alt="Lorem ipsum">
                                    </div>
                                    <div class="card-caption col-12 p-0">
                                        <div class="card-body">
                                            <a href="#">
                                                <h4 class="m-0">Data scientists are a booming profession.</h4>
                                            </a>
                                        </div>
                                        <div class="card-footer d-lg-flex align-items-center justify-content-center">
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-user"></i>John Doe</a>
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-clock"></i>3 Days Ago</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center item">
                                <div class="row card p-0 text-center">
                                    <div class="image-over">
                                        <img src="assets/images/news-3-h.jpg" alt="Lorem ipsum">
                                    </div>
                                    <div class="card-caption col-12 p-0">
                                        <div class="card-body">
                                            <a href="#">
                                                <h4 class="m-0">Successful creations using virtual reality.</h4>
                                            </a>
                                        </div>
                                        <div class="card-footer d-lg-flex align-items-center justify-content-center">
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-user"></i>John Doe</a>
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-clock"></i>3 Days Ago</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center item">
                                <div class="row card p-0 text-center">
                                    <div class="image-over">
                                        <img src="assets/images/news-4-h.jpg" alt="Lorem ipsum">
                                    </div>
                                    <div class="card-caption col-12 p-0">
                                        <div class="card-body">
                                            <a href="#">
                                                <h4 class="m-0">Is the trend these days working from home?</h4>
                                            </a>
                                        </div>
                                        <div class="card-footer d-lg-flex align-items-center justify-content-center">
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-user"></i>John Doe</a>
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-clock"></i>3 Days Ago</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center item">
                                <div class="row card p-0 text-center">
                                    <div class="image-over">
                                        <img src="assets/images/news-5-h.jpg" alt="Lorem ipsum">
                                    </div>
                                    <div class="card-caption col-12 p-0">
                                        <div class="card-body">
                                            <a href="#">
                                                <h4 class="m-0">How digital transformation has changed the world.</h4>
                                            </a>
                                        </div>
                                        <div class="card-footer d-lg-flex align-items-center justify-content-center">
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-user"></i>John Doe</a>
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-clock"></i>3 Days Ago</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center item">
                                <div class="row card p-0 text-center">
                                    <div class="image-over">
                                        <img src="assets/images/news-6-h.jpg" alt="Lorem ipsum">
                                    </div>
                                    <div class="card-caption col-12 p-0">
                                        <div class="card-body">
                                            <a href="#">
                                                <h4 class="m-0">Why project management increases performance.</h4>
                                            </a>
                                        </div>
                                        <div class="card-footer d-lg-flex align-items-center justify-content-center">
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-user"></i>John Doe</a>
                                            <a href="#" class="d-lg-flex align-items-center"><i class="icon-clock"></i>3 Days Ago</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </section>


	 <section id="partner" class="section-4 odd logos" style="padding:75px;">
            <div class="overflow-holder">
                <div class="container">
				
                    <div class="swiper-container min-slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-1.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-2.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-3.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-4.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-5.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-6.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-7.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                            <div class="swiper-slide slide-center item">
                                <img src="assets/images/logo-8.png" class="fit-image w-85" alt="Fit Image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
		
		  <!-- Testimonials -->
        <section id="testimonials" class="section-4 odd carousel featured all" style="padding-top:50px;">
            <div class="overflow-holder">
                <div class="container">
                    <div class="row text-center intro">
                        <div class="col-12">
                            <h2>Customer Testimonials</h2>
                            <p class="text-max-800">Our customers are satisfied with the work we do. The greatest gratification is to receive recognition for what we have built. This motivates us to improve even more.</p>
                        </div>
                    </div>
                    <div class="swiper-container mid-slider items">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide slide-center text-center item">
                                <div class="row card">
                                    <div class="col-12">
                                        <img src="assets/images/team-1.jpg" alt="Adams Baker" class="person" style="max-width:100px;border-radius:100%;">
                                        <h4>Adams Baker</h4>
                                        <p>My website looks amazing with the Leverage Theme.</p>
                                        <ul class="navbar-nav social share-list ml-auto">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                <div class="row card">
                                    <div class="col-12">
                                        <img src="assets/images/team-2.jpg" alt="Mary Evans" class="person" style="max-width:100px;border-radius:100%;">
                                        <h4>Mary Evans</h4>
                                        <p>This company created an exclusive form. Fantastic.</p>
                                        <ul class="navbar-nav social share-list ml-auto">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                <div class="row card">
                                    <div class="col-12">
                                        <img src="assets/images/team-3.jpg" alt="Sarah Lopez" class="person" style="max-width:100px;border-radius:100%;">
                                        <h4>Sarah Lopez</h4>
                                        <p>I'm loving the partnership. The support deserves 5 stars.</p>
                                        <ul class="navbar-nav social share-list ml-auto">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                <div class="row card">
                                    <div class="col-12">
                                        <img src="assets/images/team-4.jpg" alt="Joseph Hills" class="person" style="max-width:100px;border-radius:100%;">
                                        <h4>Joseph Hills</h4>
                                        <p>My app was perfect. I will request more services soon.</p>
                                        <ul class="navbar-nav social share-list ml-auto">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide slide-center text-center item">
                                <div class="row card">
                                    <div class="col-12">
                                        <img src="assets/images/team-5.jpg" alt="Karen Usman" class="person" style="max-width:100px;border-radius:100%;">
                                        <h4>Karen Usman</h4>
                                        <p>I had small problems with the payment, but it was resolved.</p>
                                        <ul class="navbar-nav social share-list ml-auto">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link"><i class="icon-star ml-2 mr-2"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>
        </section>


        <!-- Contact -->
        <section id="contact" class="section-7 odd form featured">
            <div class="container">
                <form action="#" id="leverage-form" class="multi-step-form">
                    <input type="hidden" name="section" value="leverage_form">

                    <input type="hidden" name="reCAPTCHA">
                    <!-- Remove this field if you want to disable recaptcha -->

                    <div class="row">
                        <div class="col-12 col-md-6 align-self-start text-center text-md-left">

                            <!-- Success Message -->
                           
                            <!-- Steps Message -->
                            <div class="row intro form-content">
                                <div class="col-12 p-0">

                                    <!-- Step Title -->
                                    <div class="step-title">
                                        <h2 class="featured alt">Let's Talk?</h2>
                                        <p>Don't wait until tomorrow. Talk to one of our consultants today and learn how to start leveraging your business.</p>
                                    </div>

                                    <!-- Step Title -->
                                    <div class="step-title">
                                        <h2 class="featured alt">Almost There</h2>
                                        <p>We need some more important information to better understand how we can help you in the best possible way.</p>
                                    </div>

                                    <!-- Step Title -->
                                    <div class="step-title">
                                        <h2 class="featured alt">Are you Ready?</h2>
                                        <p>Tell us a little about the project you need to create. This is valuable so that we can direct you to the ideal team.</p>
                                    </div>

                                </div>
                            </div>

                            <!-- Steps Group -->
                            <div class="row text-center form-content">
                                <div class="col-12 p-0">
                                    
                                    <!-- Group 1 -->
                                    <fieldset class="step-group">
                                        <div class="row">
                                            <div class="col-12 input-group p-0">
                                                <input type="email" name="email" data-minlength="3" class="form-control field-email" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12 input-group p-0">
                                                <input type="text" name="name" data-minlength="3" class="form-control field-name" placeholder="Name">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12 input-group p-0">
                                                <input type="text" name="phone" data-minlength="3" class="form-control field-phone" placeholder="Phone">
                                            </div>
                                        </div>
                                        <div class="col-12 input-group p-0">
                                            <a class="step-next btn primary-button">NEXT<i class="icon-arrow-right-circle left"></i></a>
                                        </div>
                                    </fieldset>

                                </div>
                            </div>
                        </div>

                        <div class="content-images col-12 col-md-6 pl-md-5 d-none d-md-block">

                            <!-- Step 1 -->
							<div class="gallery">
                                
                                    <img src="assets/images/contact.jpg" class="fit-image" alt="Contact Us">
                                
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- Footer -->
        <?php
		include('footer.php');
		?>

        <!-- #region Global ============================ -->

        

        <!-- Modal [responsive menu] -->
        <div id="menu" class="p-0 modal fade" role="dialog" aria-labelledby="menu" aria-hidden="true">
            <div class="modal-dialog modal-dialog-slideout" role="document">
                <div class="modal-content full">
                    <div class="modal-header" data-dismiss="modal">
                        Menu <i class="icon-close"></i>
                    </div>
                    <div class="menu modal-body">
                        <div class="row w-100">
                            <div class="items p-0 col-12 text-center">
                                <!-- Append [navbar] -->
                            </div>
                            <div class="contacts p-0 col-12 text-center">
                                <!-- Append [navbar] -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Scroll [to top] -->
        <div id="scroll-to-top" class="scroll-to-top">
            <a href="#header" class="smooth-anchor">
                <i class="icon-arrow-up"></i>
            </a>
        </div>        
        
        <!-- ==============================================
        Google reCAPTCHA // Put your site key here
        =============================================== -->
    
        <!-- ==============================================
        Vendor Scripts
        =============================================== -->
        <script src="assets/js/vendor/jquery.min.js"></script>
        <script src="assets/js/vendor/jquery.easing.min.js"></script>
        <script src="assets/js/vendor/jquery.inview.min.js"></script>
        <script src="assets/js/vendor/popper.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>
        <script src="assets/js/vendor/ponyfill.min.js"></script>
        <script src="assets/js/vendor/slider.min.js"></script>
        <script src="assets/js/vendor/animation.min.js"></script>
        <script src="assets/js/vendor/progress-radial.min.js"></script>
        <script src="assets/js/vendor/bricklayer.min.js"></script>
        <script src="assets/js/vendor/gallery.min.js"></script>
        <script src="assets/js/vendor/shuffle.min.js"></script>
        <script src="assets/js/vendor/particles.min.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="assets/js/custom.js"></script>

        <!-- #endregion Global ========================= -->

    </body>
</html>